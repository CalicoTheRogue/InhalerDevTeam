//
//  senior_projectApp.swift
//  Shared
//
//  Created by Kỳ Nguyễn on 1/28/22.
//

import SwiftUI

@main
struct senior_projectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
